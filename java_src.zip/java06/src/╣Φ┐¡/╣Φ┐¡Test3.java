package 배열;

public class 배열Test3 {

	public static void main(String[] args) {
		
		char[] num = {'A','A','C','B','F'};
		
		
		for (int j = 0; j < num.length; j++) {
			System.out.print("친구의 학점은 각각 : "+num[j]+"\n");
			
		}


	}

}
