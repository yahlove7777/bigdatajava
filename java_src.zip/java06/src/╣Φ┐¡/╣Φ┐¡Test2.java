package 배열;

public class 배열Test2 {

	public static void main(String[] args) {
		
		char[] num = {'남','남','녀','남','녀'};
		
		
		for (int j = 0; j < num.length; j++) {
			System.out.print("친구의 성별은 각각 : "+num[j]+"\n");
			
		}


	}

}
