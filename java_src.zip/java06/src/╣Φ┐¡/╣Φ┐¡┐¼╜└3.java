package 배열;

public class 배열연습3 {

	public static void main(String[] args) {
		
		int[] num1 =  {1,2,3};
		int[] num2 =  num1;





	}

}
