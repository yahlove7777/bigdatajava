package 배열;

public class 배열연습4 {

	public static void main(String[] args) {
		
		int num1 =  300;
		int num2 =  100;
		int num3 = num1;
		num2 = num1;

		System.out.println(num1);
		System.out.println(num2);
		System.out.println(num3);



	}

}
