package 배열;

public class 배열연습2 {

	public static void main(String[] args) {
		
		int[] num = {44,66,22,88};
		
		System.out.println("값들의 개수 : "+num.length);
		num[0] = 55;
		
		for (int j = 0; j < num.length; j++) {
			System.out.println("출력 값 : "+num[j]);
		}


	}

}
