package 배열;

public class 배열Test1 {

	public static void main(String[] args) {
		
		double[] num = {1.5,1.2,0.7,2.0,0.1};
		
		
		for (int j = 0; j < num.length; j++) {
			System.out.print("친구의 시력은 각각 : "+num[j]+"\n");
			
		}


	}

}
