package 배열;

public class 배열Test4 {

	public static void main(String[] args) {
		
		String[] num = {"김민영","최주호","양정은","박지하","홍길동"};
		
		
		for (int j = 0; j < num.length; j++) {
			System.out.print("친구의 이름은 각각 : "+num[j]+"\n");
			
		}


	}

}
