package 배열;

public class 배열Test5 {

	public static void main(String[] args) {
		
		int[] num = {95,100,60,72,30};
		
		for (int j = 0; j < num.length; j++) {
			System.out.print("친구의 컴퓨터 점수는 각각 : "+num[j]+"\n");
			
		}


	}

}
