package control;

import java.util.Date;

public class 영어인사 {

	public static void main(String[] args) {
		
		Date date = new Date();
		
		int hour = date.getHours();
		
		System.out.println(hour);
	}

}
