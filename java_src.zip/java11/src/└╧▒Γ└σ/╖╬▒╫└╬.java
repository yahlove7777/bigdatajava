package 일기장;

import java.awt.FlowLayout;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class 로그인 {
	private JTextField textField1;
	private JTextField textField2;

	public 로그인() {

		JFrame f = new JFrame("나의 일기장 로그인 화면");
		f.setSize(600, 600);
		JLabel l = new JLabel();
		ImageIcon icon = new ImageIcon("diary.PNG");
		l.setIcon(icon);

		FlowLayout flow = new FlowLayout();
		f.getContentPane().setLayout(flow);

		JButton btnNewButton = new JButton("로그인 처리");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = "root";
				String pw = "1234";
				if (id.equals(textField1.getText()) && pw.equals(textField2.getText())) {
					JOptionPane.showMessageDialog(null, "로그인 성공");
					다이어리 diary = new 다이어리();
				} else {
					JOptionPane.showMessageDialog(null, "아이디 또는 비밀번호가 틀렸습니다.");
				}

			}
		});

		JLabel lblNewLabel = new JLabel("ID입력:");
		f.getContentPane().add(lblNewLabel);

		textField1 = new JTextField();
		f.getContentPane().add(textField1);
		textField1.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("PW입력:");
		f.getContentPane().add(lblNewLabel_1);

		textField2 = new JPasswordField();
		f.getContentPane().add(textField2);
		textField2.setColumns(10);
		btnNewButton.setBackground(Color.PINK);
		btnNewButton.setForeground(Color.RED);
		btnNewButton.setFont(new Font("굴림", Font.PLAIN, 16));
		f.getContentPane().add(btnNewButton);
		f.getContentPane().add(l);

		f.setVisible(true);
	}

	public static void main(String[] arg) {
		로그인 log = new 로그인();
	}

}
