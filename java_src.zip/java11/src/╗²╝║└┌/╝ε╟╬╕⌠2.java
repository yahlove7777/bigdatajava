package 생성자;

import java.util.Scanner;

public class 쇼핑몰2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Member2[] Member2 = new Member2[3];
		String id;
		String pw;
		String rank;
		int mile;
		int sum = 0;
		int aver = 0;
		System.out.println("정보를 입력하세요.");
		for (int i = 0; i < Member2.length; i++) {
			System.out.print("아이디 : ");
			id = sc.next();
			System.out.print("비밀번호 : ");
			pw = sc.next();
			System.out.print("등급 : ");
			rank = sc.next();
			System.out.print("마일리지: ");
			mile = sc.nextInt();
			Member2[i] = new Member2(id,pw,rank,mile);
			sum += Member2[i].mile;
		}
		aver = sum / Member2.length;
		
		System.out.println(Member2[0].id + "의 비밀번호는 "+Member2[0].pw+" 입니다.");
		System.out.println(Member2[1].id + "의 등급은 "+Member2[1].rank+"이고, 마일리지는 "+Member2[1].mile+" 입니다.");
		System.out.println("총 마일리지는 "+sum+"입니다.");
		System.out.println("평균 마일리지는 "+aver+"입니다.");

		

		
		
	}

}
