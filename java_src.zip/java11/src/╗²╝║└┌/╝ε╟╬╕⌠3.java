package 생성자;

import java.util.Scanner;

public class 쇼핑몰3 {


	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Bank[] bank = new Bank[3];
		String product;
		String name;
		int money;

		System.out.println("정보를 입력하세요.");
		for (int i = 0; i < bank.length; i++) {
			System.out.print("상품명 : ");
			product = sc.next();
			System.out.print("예금주 : ");
			name = sc.next();
			System.out.print("예금 : ");
			money = sc.nextInt();
			bank[i] = new Bank(product,name,money);
		}
		
		System.out.println(bank[1].purduct + " 통장에는 "+bank[1].money+"만원이 들어있어요");
		System.out.println(bank[2].name + " 통장에는 "+bank[2].money+"만원이 들어있어요");


		

		
		
	}

}
