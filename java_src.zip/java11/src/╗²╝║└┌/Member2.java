package 생성자;

public class Member2 {
	
	String id;
	String pw;
	String rank;
	int mile;
	
	public Member2() {
	}

	public Member2(String id, String pw, String rank, int mile) {
		this.id = id;
		this.pw = pw;
		this.rank = rank;
		this.mile = mile;
	}
	

}
