package 생성자;

public class Bank {
	
	String purduct;
	String name;
	int money;
	
	public Bank() {
		
	}
	public Bank(String purduct, String name, int money) {
		this.purduct = purduct;
		this.name = name;
		this.money = money;
	}
	
	
	
	
}
