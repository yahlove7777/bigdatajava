package 반복문;

public class Test1 {
	
	public static void main(String[] args) {
		
		int start;
		
		for(start = 1;start <= 20; start++) {
			System.out.println("Hello Java");
		}
	}

}
