package 반복문;

public class ForTest2 {
	
	public static void main(String[] args) {
		
		int start;
		
		for(start = 1;start <= 10; start++) {
			for(int j = 1;j <= 10;j++) {
				System.out.print("★");	
			}
			System.out.println("");
		}
	}

}
