package 반복문;

import java.util.Scanner;

public class Test4 {

	public static void main(String[] args) {
		//두개의 입력값을 받아서, 첫번째값부터 두번째값까지 더함

		Scanner sc = new Scanner(System.in);
		System.out.print("입력1 : ");
		String num1 = sc.next();
		System.out.print("입력2 : ");
		String num2 = sc.next();

		
		System.out.print("**"+num1+" "+num2+"**");

	}

}
