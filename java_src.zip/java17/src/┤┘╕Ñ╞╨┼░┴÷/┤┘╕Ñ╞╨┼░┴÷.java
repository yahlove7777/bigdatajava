                                                                                                    package 다른패키지;

public class 다른패키지 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
