package java17;

public class GoodBank extends Bank{

	@Override
	public double getInterestRate() {
		
		double x = 3.0;
		
		return x;
	}
}
