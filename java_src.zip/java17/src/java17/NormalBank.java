package java17;

public class NormalBank extends Bank{

	@Override
	public double getInterestRate() {
		
		double x = 5.0;
		
		return x;
	}
}
