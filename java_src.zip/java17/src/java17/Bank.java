package java17;

public class Bank {
	
	public double getInterestRate() {
		
		double x = 5.0;
		
		return x;
		
		
	}
}
