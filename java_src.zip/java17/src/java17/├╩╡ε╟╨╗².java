package java17;

public class 초등학생 extends 학생 {
	
	@Override
	public void 공부하다() {
		System.out.println("영어공부");
	}
}
