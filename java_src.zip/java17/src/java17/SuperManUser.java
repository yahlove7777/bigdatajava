package java17;

class SuperManUser {

	public static void main(String[] args) {
		SuperMan su = new SuperMan();
		
		su.height = 200;
		su.weight = 100;
		su.eye = 3;
		su.fly = true;
		System.out.println(su);
		su.eat();
		su.sleep();
		su.army();
		su.filySpeed();

	}

}
