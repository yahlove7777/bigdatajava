package java17;

public class 학생 {
	int study;
	
	public void sleeping() {
		System.out.println("졸리다");
	}
	public void 공부하다() {
		System.out.println("공부하다");
	}
}
