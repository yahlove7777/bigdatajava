package java17;

public class BadBank extends Bank{
	
	
	@Override
	public double getInterestRate() {
		
		double x = 10.0;
		
		return x;
	}
}
