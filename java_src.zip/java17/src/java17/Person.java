package java17;

public class Person {
	int height;
	int weight;
	
	public void eat() {
		System.out.println("밥을 먹다");
	}
	public void sleep() {
		System.out.println("잠을 자다");
	}
}
