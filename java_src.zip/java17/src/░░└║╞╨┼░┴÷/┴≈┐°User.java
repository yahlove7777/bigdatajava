package 같은패키지;

public class 직원User {

	public static void main(String[] args) {
		직원 name = new 직원();
		name.age = 100;
		name.name = "park";
		name.salary = 100;
		
		

	}

}
