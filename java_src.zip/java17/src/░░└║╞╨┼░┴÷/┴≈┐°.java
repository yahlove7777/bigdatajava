package 같은패키지;

public class 직원 {
public String name;
protected int salary;
int age ;
private String ssn;
}
