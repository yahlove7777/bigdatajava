package 배열;


public class Test6 {

	public static void main(String[] args) {

		int[] num = {66,77,88,99};
		int max;
		
		max = num[0];
		
		for (int i = 0; i < num.length; i++) {
			if(max < num[i]) {
				max = num[i];
			}
		}
		System.out.println("최대 값은 : "+max);
		

	}
}
