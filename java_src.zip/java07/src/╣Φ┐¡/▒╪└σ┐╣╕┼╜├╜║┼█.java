package 배열;

import java.util.Scanner;

public class 극장예매시스템 {

	public static void main(String[] args) {
		int[] num = new int[10];
		Scanner sc = new Scanner(System.in);
		int sum = 0;
		while(true) {
			System.out.println("---------------------------------------");
			for (int i = 0; i < 10; i++) {
				System.out.print(i+1+"   ");
			}
			System.out.println();
			System.out.println("---------------------------------------");
			for (int i = 0; i < 10; i++) {
				System.out.print(num[i]+"   ");
			}
			System.out.println();
			System.out.println("=======================================");
			System.out.print("종료는 x, 예매는 o : ");
			String end = sc.next();
			if(end.equals("x")) {
				break;
			}
			System.out.print("예매할 좌석 번호를 입력 (종료는 -1): ");
			int input = sc.nextInt();
			if(input == -1) {
				System.out.println("시스템을 종료합니다.");
				break;
			}
			else if(num[input-1] != 1) {
					num[input-1] = 1;
					System.out.println("좌석 예매 완료");
					sum = sum + 1;
			}else {
				System.out.println("이미 예매 된 좌석입니다.");
				System.out.println("다른 좌석을 예매 해 주세요");

			}
			}
			System.out.println("=====================================");
			System.out.println("예매 된 좌석의 수는 "+sum+"개 입니다.");
			System.out.println("총 가격은 "+sum*10000+"원 입니다.");
		}
	}

