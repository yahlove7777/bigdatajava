package 배열;

import java.util.Scanner;

public class Test1 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		String[] num = new String[3];
		
		System.out.println("값 3개를 넣으세요.");
		
		for (int i = 0; i < num.length; i++) {
			System.out.print("입력 >>");
			num[i] = sc.next();
			
		}
		
		System.out.println("**"+num[0]+"보다는"+num[2]+"**");

	}

}
