package 배열;

import java.util.Scanner;

public class 데이터에입력받아배열에넣기 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int[] num = new int[3];
		
		System.out.println("값 3개를 넣으세요.");
		
		for (int i = 0; i < num.length; i++) {
			System.out.print("숫자 입력 >>");
			num[i] = sc.nextInt();
			
		}
		for (int i : num) {
			System.out.println(i);
			
		}
	}

}
