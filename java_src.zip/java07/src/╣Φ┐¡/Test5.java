package 배열;


public class Test5 {

	public static void main(String[] args) {

		int[] num1 = {11,22,33,44};

		for (int i = 0; i < num1.length; i++) {
			
			if(num1[i] == 33) {
				System.out.println("33의 위치는 "+(i+1)+"번째 위치입니다.");
			}
		}
		

	}
}
