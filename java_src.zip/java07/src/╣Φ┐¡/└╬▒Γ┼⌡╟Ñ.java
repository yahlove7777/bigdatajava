package 배열;

import java.util.Scanner;

public class 인기투표 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String[] singer = new String[3];
		int[] sum = new int[3];
		for (int i = 0; i < 3; i++) {
			System.out.print("가수이름 입력 : ");
			singer[i] = sc.next();
		}
		System.out.println(singer[0]+", "+singer[1]+", "+singer[2]);
		System.out.println("------------------------");
		while(true) {
			System.out.println("(1) "+singer[0]+" (2) "+singer[1]
								+" (3) "+singer[2]);
			System.out.print("투표 번호[종료는 -1] : ");
			int tu = sc.nextInt();
			if(tu == -1) {
				System.out.println("------------------------");
				System.out.println("투표를 종료합니다.");
				System.out.println("------------------------");
				break;
			}
			else if(tu == 1) {
				sum[0] += 1;
			}
			else if(tu == 2) {
				sum[1] += 1;
			}
			else if(tu == 3) {
				sum[2] += 1;
			}
		}
		System.out.println(singer[0]+" : "+sum[0]+"표");
		System.out.println(singer[1]+" : "+sum[1]+"표");
		System.out.println(singer[2]+" : "+sum[2]+"표");
	}

}
