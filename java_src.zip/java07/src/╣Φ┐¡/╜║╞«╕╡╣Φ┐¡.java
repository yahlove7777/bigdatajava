package 배열;

public class 스트링배열 {

	public static void main(String[] args) {
		int[] ages = {50,100,10};
		String[] name = {"홍길동","박길동","최길동","김민영"}; 
		name[2] = "김동길";
		name[name.length-1] = "김동순";
		
		for (int i = 0; i < ages.length; i++) {
			System.out.println(ages[i]);
	
		}
		for (int i = 0; i < name.length; i++) {
			System.out.println(name[i]);
		}
		
		for (int imsi : ages) {
			System.out.println(imsi);
		}
		
		for (String imsi : name) {
			System.out.println(imsi);
		}

		
		

	}

}
