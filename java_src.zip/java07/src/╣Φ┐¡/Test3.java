package 배열;

import java.util.Scanner;

public class Test3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int sum = 0;
		int[] num = new int[5];
		

		for (int i = 0; i < num.length; i++) {
			System.out.print("성적을 입력하시오: ");
			num[i] = sc.nextInt();
		}
		
		for (int i : num) {
			sum = sum + i;
		}
		System.out.println("평균 성적은 "+sum/5+"입니다");


	}
}
