package 배열;

public class 값이없는배열 {

	public static void main(String[] args) {
		int[] num = new int[3];
		
		
		
		System.out.println(num[0]);

	}

}
