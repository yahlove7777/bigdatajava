package 배열;


public class Test4 {

	public static void main(String[] args) {

		int[] num1 = new int[5];

		for (int i = 0; i < num1.length; i++) {
			num1[i] = num1[i]+i;
			System.out.println(num1[i]+1);
			
		}
		

	}
}
