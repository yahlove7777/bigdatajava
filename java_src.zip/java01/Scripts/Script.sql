

create table person4(	
id varchar(10) primary key,
pw varchar(10),
name varchar(10),
tel varchar(10)
)

