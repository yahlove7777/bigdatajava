package data;

public class Hi {

	public static void main(String[] args) {
		// 나의 첫 프로그램
		
		System.out.println("나의 첫 프로그램 입니다.");
		System.out.print("나의 두번째 줄 프로그램 입니다.");
	}

}
