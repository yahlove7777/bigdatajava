package data;

public class Me {

	public static void main(String[] args) {
		
		String name = "김민영";	//이름
		String gender = "남자";	//성별
		int age = 27;			//나이
		int weight = 79;		//몸무게
		double height = 178.2;	//키
		double sight = 0.7;		//시력
		
		System.out.println("내 이름은 "+name+" 이고, 나이는 "+age+"세 입니다.");
		System.out.println("나의 키는 "+height+"cm 이고, 몸무게는 "+weight+"Kg 입니다.");
		System.out.println("시력은 "+sight+" 이고, 성별은 "+gender+" 입니다.");
		
	}

}
