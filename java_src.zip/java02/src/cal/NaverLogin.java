package cal;

public class NaverLogin {

	public static void main(String[] args) {
		
		//String id = "root";
		//String pw = "1234";
		
		int id = 1111;
		int pw = 2222;

		if (id == 1111 && pw == 2222) {
			System.out.println("로그인 성공");
		}
		else {
			System.out.println("로그인 실패");
		}
	}

}
