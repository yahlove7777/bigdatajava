package cal;

public class If3 {

	public static void main(String[] args) {
		
		int hour = 4;
		int min = 17;
		int c = 25;
		
		System.out.println("[오늘과 관련된 내용입니다.]");
		System.out.println("---------------------");
		System.out.printf("지금은 %d시 %d분 입니다.\n",hour,min);
		System.out.println("오늘의 기온은 "+c+"도 입니다.");
		System.out.println("오늘은 정말 덥습니다.");
		System.out.println("---------------------");

	}

}
