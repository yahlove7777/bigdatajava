package cal;

public class If {

	public static void main(String[] args) {
		
		int x = 200;
		int y = 100;
		int z = x + y;
		
		if(z >= 300) {
			System.out.println(300-100);
		}
		else{
			System.out.println(300*0.1);
		}
	}

}
