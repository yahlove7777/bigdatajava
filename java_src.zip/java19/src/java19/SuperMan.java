package java19;

public class SuperMan extends Man{
	
	String power;
	String speed;
	
	public SuperMan() {
		System.out.println("SuperMan의 기본생성자..");
	}

	public SuperMan(String power, String speed) {
		super();
		this.power = power;
		this.speed = speed;
	}
	
}
