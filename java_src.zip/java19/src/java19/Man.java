package java19;

public class Man {

	String name;
	int age;
	
	public Man() {
		System.out.println("Man의 기본생성자");
	}

	public Man(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	

	
}
