package java19;

public class Truck extends Car{

	
	int weigth;
	int length;
	
	public Truck() {
		System.out.println("트력 객체 생성..");
	}

	public Truck(int weigth, int length) {
		super();//자식 클래스 생성 시 부모생성자를 무조건 호출
		this.weigth = weigth;
		this.length = length;
	}
	
}
