package java19;

public class CarUser {

	public static void main(String[] args) {
		Car car = new Car();
		
		

	}

}
