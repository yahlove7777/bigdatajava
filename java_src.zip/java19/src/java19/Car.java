package java19;

public class Car {
	String color;
	int speed;
	
	public Car() {
		System.out.println("차 객체 생성..");
	}
	
	public Car(String color, int speed) {
		super();
		this.color = color;
		this.speed = speed;
	}
}
