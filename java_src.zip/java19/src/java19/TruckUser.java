package java19;

public class TruckUser {

	public static void main(String[] args) {
		new Truck();

	}

}
