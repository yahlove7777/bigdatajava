package java19;

public class ManUser {

	public static void main(String[] args) {
		new SuperMan("name","s");

	}

}