package carcrud;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class CarDAO {
	// 정적멤버변수
	Connection con;
	PreparedStatement ps;
	String url;
	String user;
	String password;
	String sql;
	ResultSet rs;
	// 멤버메소드


	public ArrayList select(String id) {

		CarDTO dto = null;
		ArrayList list = new ArrayList();

		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 드라이버설정 ok");

			url = "jdbc:mysql://localhost:3306/car";
			user = "root";
			password = "1234";
			con = DriverManager.getConnection(url, user, password);
			System.out.println("2. db연결 ok");

			String sql = "select * from carsale where id = ?";
			ps = con.prepareStatement(sql);
			ps.setString(1, id);
			System.out.println("3. SQL문 객체화 ok");

			rs = ps.executeQuery();
			System.out.println("4. SQL문 전송 ok");

			while (rs.next()) {
				dto = new CarDTO();
				String id2 = rs.getString(1);
				String name = rs.getString(2);
				String content = rs.getString(3);
				String price = rs.getString(4);
				dto.setId(id2);
				dto.setName(name);
				dto.setContent(content);
				dto.setPrice(price);
				list.add(dto);

			}

		} catch (Exception e) {
			System.out.println("에러발생!!");
			System.out.println(e.getMessage());
		} finally {
			try {
				rs.close();
				ps.close();
				con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public ArrayList selectall() {

		CarDTO dto = null;
		ArrayList list = new ArrayList();

		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 드라이버설정 ok");

			url = "jdbc:mysql://localhost:3306/car";
			user = "root";
			password = "1234";
			con = DriverManager.getConnection(url, user, password);
			System.out.println("2. db연결 ok");

			String sql = "select * from carsale";
			ps = con.prepareStatement(sql);
			System.out.println("3. SQL문 객체화 ok");

			rs = ps.executeQuery();
			System.out.println("4. SQL문 전송 ok");

			while(rs.next()) {
				dto = new CarDTO();
				String id2 = rs.getString(1);
				String name = rs.getString(2);
				String content = rs.getString(3);
				String price = rs.getString(4);
				dto.setId(id2);
				dto.setName(name);
				dto.setContent(content);
				dto.setPrice(price);
				list.add(dto);

			}

		} catch (Exception e) {
			System.out.println("에러발생!!");
			System.out.println(e.getMessage());
		} finally {
			try {
				rs.close();
				ps.close();
				con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	public void insert(CarDTO dto) throws Exception {

		// 1. 드라이버 설정(예외처리)
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("1. 드라이버 설정 OK");

		// 2. DB 연결(DB명, id, pw)
		url = "jdbc:mysql://localhost:3306/car";
		user = "root";
		password = "1234";
		con = DriverManager.getConnection(url, user, password);
		System.out.println("2. DB 연결 OK");

		// 3. SQL문 선택
		sql = "insert into carsale values(?,?,?,?)";
		PreparedStatement ps = con.prepareStatement(sql);
		ps = con.prepareStatement(sql);
		ps.setString(1, dto.getId());
		ps.setString(2, dto.getName());
		ps.setString(3, dto.getContent());
		ps.setString(4, dto.getPrice());

		System.out.println("3. SQL문 결정 OK");

		// 4. SQL문 전송
		ps.executeUpdate();
		System.out.println("4. SQL문 전송 완료");

		ps.close();
		con.close();
	}

	public void update(String id, String price) throws Exception {

		// 1. 드라이버 설정(예외처리)
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("1. 드라이버 설정 OK");

		// 2. DB 연결(DB명, id, pw)
		url = "jdbc:mysql://localhost:3306/car";
		user = "root";
		password = "1234";
		con = DriverManager.getConnection(url, user, password);
		System.out.println("2. DB 연결 OK");

		// 3. SQL문 선택
		sql = "update carsale set price = ? where id = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps = con.prepareStatement(sql);
		ps.setString(1, price);
		ps.setString(2, id);

		System.out.println("3. SQL문 결정 OK");

		// 4. SQL문 전송
		ps.executeUpdate();
		System.out.println("4. SQL문 전송 완료");
		ps.close();
	}

	public void delete(String id) throws Exception {

		// 1. 드라이버 설정(예외처리)
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("1. 드라이버 설정 OK");

		// 2. DB 연결(DB명, id, pw)
		url = "jdbc:mysql://localhost:3306/car";
		user = "root";
		password = "1234";
		con = DriverManager.getConnection(url, user, password);
		System.out.println("2. DB 연결 OK");

		// 3. SQL문 선택
		sql = "delete from carsale where id = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps = con.prepareStatement(sql);
		ps.setString(1, id);

		System.out.println("3. SQL문 결정 OK");

		// 4. SQL문 전송
		ps.executeUpdate();
		System.out.println("4. SQL문 전송 완료");
		ps.close();
	}
}
