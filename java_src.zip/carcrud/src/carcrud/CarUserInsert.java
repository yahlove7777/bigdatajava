package carcrud;

import javax.swing.JOptionPane;

public class CarUserInsert {

	public static void main(String[] args) {
		String id = JOptionPane.showInputDialog("삽입할 ID입력");
		String name = JOptionPane.showInputDialog("삽입할 NAME입력");
		String content = JOptionPane.showInputDialog("삽입할 CONTENT입력");
		String price = JOptionPane.showInputDialog("삽입할 PRICE입력");

		CarDAO dao = new CarDAO();
		CarDTO dto = new CarDTO();

		dto.setId(id);
		dto.setName(name);
		dto.setContent(content);
		dto.setPrice(price);

		try {
			dao.insert(dto);
		} catch (Exception e) {
			System.out.println("에러발생!!");
			e.printStackTrace();
		}

	}

}
