package carcrud;

import java.util.ArrayList;

import javax.swing.JOptionPane;


public class CarUserSelect {

	public static void main(String[] args) {
		String id = JOptionPane.showInputDialog("검색할 ID 입력");
		CarDAO dao = new CarDAO();
		ArrayList list = dao.select(id);

		for (int i = 0; i < list.size(); i++) {
			CarDTO dto = (CarDTO)list.get(i);
			System.out.println();
			System.out.println("검색된 ID : " + dto.getId());
			System.out.println("검색된 NAME : " + dto.getName());
			System.out.println("검색된 CONTENT : " + dto.getContent());
			System.out.println("검색된 PRICE : " + dto.getPrice());
		} 
	}

}
