package carcrud;

import javax.swing.JOptionPane;

public class CarUserDelete {

	public static void main(String[] args) {
		String id = JOptionPane.showInputDialog("삭제할 ID입력");

		CarDAO dao = new CarDAO();
		try {
			dao.delete(id);
		} catch (Exception e) {
			System.out.println("에러발생!!");
			e.printStackTrace();
		}

	}

}
