package carcrud;

import javax.swing.JOptionPane;

public class CarUserUpdate {

	public static void main(String[] args) {
		String id = JOptionPane.showInputDialog("ID입력");
		String price = JOptionPane.showInputDialog("변경할 PRICE 입력");

		CarDAO db = new CarDAO();
		try {
			db.update(id, price);
		} catch (Exception e) {
			System.out.println("에러발생!!");
			e.printStackTrace();
		}

	}

}
