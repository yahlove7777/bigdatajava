package carcrud;

import java.util.ArrayList;

import javax.swing.JOptionPane;

public class CarUserSelectAll {

	public static void main(String[] args) {
		
		CarDAO dao = new CarDAO();
		ArrayList list = dao.selectall();

		for (int i = 0; i < list.size(); i++) {
			CarDTO dto = (CarDTO) list.get(i);
			System.out.println();
			System.out.println("검색된 ID : " + dto.getId());
			System.out.println("검색된 NAME : " + dto.getName());
			System.out.println("검색된 CONTENT : " + dto.getContent());
			System.out.println("검색된 PRICE : " + dto.getPrice());
			System.out.println();
		}

	}
}
