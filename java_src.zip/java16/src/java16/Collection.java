package java16;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Vector;

public class Collection {

	public static void main(String[] args) {
		ArrayList arr = new ArrayList();
		Vector vec = new Vector();
		HashSet hash = new HashSet();
		
		arr.add("박스키");
		arr.add("송스키");
		arr.add("김스키");
		arr.add("정스키");
		
		int size = arr.size();
		
		System.out.println("리스트의 개수는 : "+size+"개");
		arr.remove("송스키");
		System.out.println(arr);//to String Override
		arr.add(1, "뉴인물");
		System.out.println(arr);//to String Override
		arr.set(1, "올드인물");
		System.out.println(arr);//to String Override
		
		for (int i = 0; i < arr.size(); i++) {
			System.out.println(i+1+"등은 "+arr.get(i)+" 입니다");
		}
//		arr.remove(0);
//		System.out.println(arr);//to String Override
//		arr.remove(1);
//		System.out.println(arr);//to String Override
//		arr.remove("정스키");
//		System.out.println(arr);//to String Override
		
		

		

	}

}
