package java16;

import java.util.ArrayList;

public class CollectionTest1 {

	public static void main(String[] args) {
		ArrayList arr = new ArrayList();
		
		arr.add("박소정");
		arr.add("김정민");
		arr.add("소지현");
		arr.add("김개념");
		
		
		arr.remove(1);
		for (int i = 0; i < arr.size(); i++) {
			System.out.println(i+1+"등 : "+arr.get(i));
		}

	}

	
}
