package java16;

import java.util.ArrayList;

public class MemberDAO {
	public ArrayList selectAll() {
		ArrayList list = new ArrayList();
		MemberDTO d1 = new MemberDTO("admin","1234","kim","010");
		MemberDTO d2 = new MemberDTO("user","1111","lee","011");
		MemberDTO d3 = new MemberDTO("mem","2222","lim","016");
		
		list.add(d1);
		list.add(d2);
		list.add(d3);
		
		return list;
		
	}
}
