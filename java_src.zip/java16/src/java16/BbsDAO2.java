package java16;

import java.util.ArrayList;

public class BbsDAO2 {

	public ArrayList selectAll() {
		BbsDTO b1 = new BbsDTO("100","java","fun","100");
		BbsDTO b2 = new BbsDTO("200","jsp","fun jsp","200");
		BbsDTO b3 = new BbsDTO("300","Spring","fun Spring","300");
		BbsDTO b4 = new BbsDTO("400","android","fun android","400");

		ArrayList arr = new ArrayList();
		
		arr.add(b1);
		arr.add(b2);
		arr.add(b3);
		arr.add(b4);
	
		return arr;


	}
}
