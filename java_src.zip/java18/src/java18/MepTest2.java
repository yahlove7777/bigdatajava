package java18;

import java.util.HashMap;

public class MepTest2 {

	public static void main(String[] args) {
		HashMap member = new HashMap();
		member2 name = new member2("kim",20,'남',"구로구","010");
		member2 name2 = new member2("park",25,'여',"강남구","011");
		member2 name3 = new member2("lee",22,'남',"마포구","012");
		member.put("m100", name);
		member.put("m200", name2);
		member.put("m300", name3);
		
		System.out.println(member);
		

	}

}
