package java18;

import java.util.HashMap;

public class Quiz1 {

	public static void main(String[] args) {
		HashMap list = new HashMap();
		QuizClass g1 = new QuizClass("해리포터","판타지","조앤K롤링","1234");
		QuizClass g2 = new QuizClass("신","판타지","베르나르베르베르","5678");
		QuizClass g3 = new QuizClass("개미","공상과학","베르나르베르베르","1011");
		
		list.put(100,g1);
		list.put(200,g2);
		list.put(300,g3);
		
		System.out.println(list.get(100));
		System.out.println(list.get(200));
		System.out.println(list.get(300));
		

	}

}
