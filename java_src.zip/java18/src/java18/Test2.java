package java18;

import java.util.HashSet;

public class Test2 {

	public static void main(String[] args) {
		HashSet set = new HashSet();
		
		set.add("디자이너");
		set.add("프로그래머");
		set.add("DB관리자");
		
		System.out.println(set);
		
		System.out.println(set.contains("디자이너"));

	}

}
