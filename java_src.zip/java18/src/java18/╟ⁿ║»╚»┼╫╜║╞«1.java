package java18;

public class 형변환테스트1 {

	public static void main(String[] args) {
		//형변환(type Change : 타입변환, Casting[캐스팅])
		//기초형 형변환
		//작은것 -> 큰것 : 자동 형 변환
		byte a = 127;
		int b = a;
		System.out.println(b);
		
		//큰 -> 작은 : 강제 형변환
		int c = 127;
		byte d = (byte)c;

		//참조형 형변환(클래스의 형변환)
		//상속관계에 있는 클래스들만 가능
		//작(자식)->큰(부모) : 자동형변환
		
		
		//큰(부모)->작(자식) : 강제형변환
	}

}
