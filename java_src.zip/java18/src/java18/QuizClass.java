package java18;

public class QuizClass {
	String title;
	String contect;
	String name;
	String pw;
	
	
	public QuizClass(String title, String contect, String name, String pw) {
		super();
		this.title = title;
		this.contect = contect;
		this.name = name;
		this.pw = pw;
	}


	@Override
	public String toString() {
		return "QuizClass [title=" + title + ", contect=" + contect + ", name=" + name + ", pw=" + pw + "]";
	}
	
	
	
	
}
