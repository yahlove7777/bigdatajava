package java18;

import java.util.ArrayList;

public class litstTest2 {

	public static void main(String[] args) {
		ArrayList list = new ArrayList();
		
		list.add("나는스트링");
		list.add(100);
		int a = 100;
		
		String b = "100";
		
		

	}

}
