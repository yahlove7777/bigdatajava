package ticket;

import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JOptionPane;

public class TicketSelect {

	public static void main(String[] args) {
		String mname = JOptionPane.showInputDialog("검색할 영화제목 입력");
		TicketDao dao = new TicketDao();
		ArrayList list = dao.select(mname);
		
		for (int i = 0; i < list.size(); i++) {
			TicketDto dto = (TicketDto)list.get(i);
			System.out.println("검색된 영화제목 : " + dto.getMname());
			System.out.println("검색된 영화관 : " + dto.getCity());
			System.out.println("검색된 날짜 : " + dto.getDay());
			System.out.println("검색된 상영관 : " + dto.getHall());
			System.out.println("검색된 시간 : " + dto.getTime());
			System.out.println("검색된 좌석 : " + dto.getSeat());
			System.out.println("검색된 가격 : " + dto.getPrice());
			System.out.println();
		} 


		
		
		
		
	}

}
