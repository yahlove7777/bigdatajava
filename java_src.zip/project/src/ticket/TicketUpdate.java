package ticket;

import javax.swing.JOptionPane;

public class TicketUpdate {

	public static void main(String[] args){
		String mname = JOptionPane.showInputDialog("영화제목입력");
		String hall = JOptionPane.showInputDialog("변경할 상영관 입력");
		String time = JOptionPane.showInputDialog("변경할 상영시간 입력");
		String seat = JOptionPane.showInputDialog("변경할 좌석 입력");

		
		TicketDao db = new TicketDao();
		try {
			db.update(mname, hall, time, seat);
		} catch (Exception e) {
			System.out.println("에러발생!!");
			e.printStackTrace();
		}
		

	}

}
