package ticket;

import javax.swing.JOptionPane;

public class TicketDelete {

	public static void main(String[] args){
		String mname = JOptionPane.showInputDialog("삭제할 영화제목 입력");

		
		TicketDao db = new TicketDao();
		try {
			db.delete(mname);
		} catch (Exception e) {
			System.out.println("에러발생!!");
			e.printStackTrace();
		}

	}

}
