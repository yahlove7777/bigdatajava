package ticket;


import javax.swing.JOptionPane;


public class TicketInsert {

	public static void main(String[] args){
		String mname = JOptionPane.showInputDialog("영화 이름 입력");
		String city = JOptionPane.showInputDialog("지역 입력");
		String day = JOptionPane.showInputDialog("날짜 입력");
		String hall = JOptionPane.showInputDialog("상영관 입력");
		String time = JOptionPane.showInputDialog("상영시간 입력");
		String seat = JOptionPane.showInputDialog("좌석 입력");
		String price = JOptionPane.showInputDialog("가격 입력");
		
		TicketDao db = new TicketDao();
		TicketDto dto = new TicketDto();
		
		dto.setMname(mname);
		dto.setCity(city);
		dto.setDay(day);
		dto.setHall(hall);
		dto.setHall(hall);
		dto.setTime(time);
		dto.setSeat(seat);
		dto.setPrice(price);
		
		try {
			db.insert(dto);
		} catch (Exception e) {
			System.out.println("에러발생!!");
			e.printStackTrace();
		}

	}

}
