package member;


import javax.swing.JOptionPane;


public class MemberInsert {

	public static void main(String[] args){
		String id = JOptionPane.showInputDialog("가입할 ID입력");
		String pw = JOptionPane.showInputDialog("가입할 비밀번호입력");
		String name = JOptionPane.showInputDialog("가입할 이름입력");
		String tel = JOptionPane.showInputDialog("가입할 전화번호입력");
		String addr = JOptionPane.showInputDialog("가입할 주소입력");
		
		MemberDao db = new MemberDao();
		MemberDto dto = new MemberDto();
		
		dto.setId(id);
		dto.setPw(pw);
		dto.setName(name);
		dto.setTel(tel);
		dto.setAddr(addr);
		
		try {
			db.insert(dto);
		} catch (Exception e) {
			System.out.println("에러발생!!");
			e.printStackTrace();
		}

	}

}
