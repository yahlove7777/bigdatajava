package member;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import ticket.TicketDto;

public class MemberDao {
	// 정적멤버변수
	Connection con;
	PreparedStatement ps;
	String url;
	String user;
	String password;
	String sql;
	ResultSet rs;
	// 멤버메소드

	public ArrayList selectall() {

		MemberDto dto = null;

		ArrayList list = new ArrayList();

		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 드라이버설정 ok");
			url = "jdbc:mysql://localhost:3306/car";
			user = "root";
			password = "1234";
			con = DriverManager.getConnection(url, user, password);
			System.out.println("2. db연결 ok");
			String sql = "select * from member";
			ps = con.prepareStatement(sql);
			System.out.println("3. SQL문 객체화 ok");
			rs = ps.executeQuery();
			System.out.println("4. SQL문 전송 ok");

			while (rs.next()) {
				dto = new MemberDto();

				String id2 = rs.getString(1);
				String pw = rs.getString(2);
				String name = rs.getString(3);
				String tel = rs.getString(4);
				String addr = rs.getString(5);
				dto.setId(id2);
				dto.setPw(pw);
				dto.setName(name);
				dto.setTel(tel);
				dto.setAddr(addr);
				list.add(dto);
			}

		} catch (Exception e) {
			System.out.println("에러발생!!");
			System.out.println(e.getMessage());
		} finally {
			try {
				rs.close();
				ps.close();
				con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	public MemberDto select(String id) {

		MemberDto dto = null;
		int x = 0;
		

		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 드라이버설정 ok");

			url = "jdbc:mysql://localhost:3306/movie";
			user = "root";
			password = "1234";
			con = DriverManager.getConnection(url, user, password);
			System.out.println("2. db연결 ok");

			String sql = "select * from member where id = ?";
			ps = con.prepareStatement(sql);
			ps.setString(1, id);
			System.out.println("3. SQL문 객체화 ok");

			rs = ps.executeQuery();
			System.out.println("4. SQL문 전송 ok");

			if (rs.next()) {
				dto = new MemberDto();
				String id2 = rs.getString(1);
				String pw = rs.getString(2);
				String name = rs.getString(3);
				String tel = rs.getString(4);
				String addr = rs.getString(5);
				dto.setId(id2);
				dto.setPw(pw);
				dto.setName(name);
				dto.setTel(tel);
				dto.setAddr(addr);
				

			}

		} catch (Exception e) {
			System.out.println("에러발생!!");
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
				con.close();
			} catch (Exception e) {
				e.printStackTrace();
			} // catch
		}// finally
		
		return dto;
	}// select

	public void insert(MemberDto dto) throws Exception {

		// 1. 드라이버 설정(예외처리)
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("1. 드라이버 설정 OK");

		// 2. DB 연결(DB명, id, pw)
		url = "jdbc:mysql://localhost:3306/movie";
		user = "root";
		password = "1234";
		con = DriverManager.getConnection(url, user, password);
		System.out.println("2. DB 연결 OK");

		// 3. SQL문 선택
		sql = "insert into member values(?,?,?,?,?)";
		PreparedStatement ps = con.prepareStatement(sql);
		ps = con.prepareStatement(sql);
		ps.setString(1, dto.getId());
		ps.setString(2, dto.getPw());
		ps.setString(3, dto.getName());
		ps.setString(4, dto.getTel());
		ps.setString(5, dto.getAddr());

		System.out.println("3. SQL문 결정 OK");

		// 4. SQL문 전송
		int result = ps.executeUpdate();
		System.out.println("4. SQL문 전송 완료");

		if (result == 1) {
			JOptionPane.showMessageDialog(null, "회원가입 성공!");
		} else {
			JOptionPane.showMessageDialog(null, "회원가입 실패!!");
		}
		ps.close();
		con.close();
	}

	public void update(String id, String pw, String tel) throws Exception {

		// 1. 드라이버 설정(예외처리)
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("1. 드라이버 설정 OK");

		// 2. DB 연결(DB명, id, pw)
		url = "jdbc:mysql://localhost:3306/movie";
		user = "root";
		password = "1234";
		con = DriverManager.getConnection(url, user, password);
		System.out.println("2. DB 연결 OK");

		// 3. SQL문 선택
		sql = "update member set pw = ?, tel = ? where id = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps = con.prepareStatement(sql);
		ps.setString(1, pw);
		ps.setString(2, tel);
		ps.setString(3, id);

		System.out.println("3. SQL문 결정 OK");

		// 4. SQL문 전송
		ps.executeUpdate();
		System.out.println("4. SQL문 전송 완료");
		ps.close();
	}

	public void delete(String id) throws Exception {

		// 1. 드라이버 설정(예외처리)
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("1. 드라이버 설정 OK");

		// 2. DB 연결(DB명, id, pw)
		url = "jdbc:mysql://localhost:3306/movie";
		user = "root";
		password = "1234";
		con = DriverManager.getConnection(url, user, password);
		System.out.println("2. DB 연결 OK");

		// 3. SQL문 선택
		sql = "delete from member where id = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps = con.prepareStatement(sql);
		ps.setString(1, id);

		System.out.println("3. SQL문 결정 OK");

		// 4. SQL문 전송
		ps.executeUpdate();
		System.out.println("4. SQL문 전송 완료");
		ps.close();
	}

}
