package member;

import javax.swing.JOptionPane;

public class MamberUpdate {

	public static void main(String[] args){
		String id = JOptionPane.showInputDialog("ID입력");
		String pw = JOptionPane.showInputDialog("변경할 비밀번호 입력");
		String tel = JOptionPane.showInputDialog("변경할 전화번호 입력");

		
		MemberDao db = new MemberDao();
		try {
			db.update(id, pw, tel);
		} catch (Exception e) {
			System.out.println("에러발생!!");
			e.printStackTrace();
		}
		

	}

}
