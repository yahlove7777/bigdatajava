package member;

import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JOptionPane;

public class MemberSelect {

	public static void main(String[] args) {
		String id = JOptionPane.showInputDialog("검색할 ID 입력");
		MemberDao dao = new MemberDao();
		MemberDto dto = dao.select(id);

		System.out.println("검색된 ID : " + dto.getId());
		System.out.println("검색된 PW : " + dto.getPw());
		System.out.println("검색된 이름 : " + dto.getName());
		System.out.println("검색된 전화번호 : " + dto.getTel());
		System.out.println("검색된 주소 : " + dto.getAddr());
		System.out.println();

	}

}
