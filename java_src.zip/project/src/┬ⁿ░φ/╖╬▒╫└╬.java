package 참고;

import java.awt.FlowLayout;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

import member.MemberDao;
import member.MemberDto;

public class 로그인 {
	private JTextField textField1;
	private JTextField textField2;

	public 로그인() {

		JFrame f = new JFrame("영화 예매 프로그램");
		f.setSize(360, 111);
		JLabel l = new JLabel();

		FlowLayout flow = new FlowLayout();
		f.getContentPane().setLayout(flow);

		JButton btnNewButton = new JButton("로그인");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				String id = textField1.getText();
				String pw = textField2.getText();
				String adminid = "admin";
				String adminpw = "admin2";

				MemberDao dao = new MemberDao();
				MemberDto dto = dao.select(id);

				if (id.equals(dto.getId()) && pw.equals(dto.getPw())) {
					if (adminid.equals(dto.getId()) && adminpw.equals(dto.getPw())) {
						JOptionPane.showMessageDialog(null, "로그인 성공");
						회원가입 member = new 회원가입();
						f.setVisible(false);
					} else {
						JOptionPane.showMessageDialog(null, "로그인 성공");
						다이어리 diary = new 다이어리();
						f.setVisible(false);
					}
				}
				else if(id.equals("")) {
					JOptionPane.showMessageDialog(null, "아이디 또는 비밀번호를 입력해주세요.");
				}
				else {
					JOptionPane.showMessageDialog(null, "아이디 또는 비밀번호가 틀렸습니다.");
					textField1.setText("");
					textField2.setText("");
				}

			}
		});

		JLabel lblNewLabel = new JLabel("ID입력:");
		f.getContentPane().add(lblNewLabel);

		textField1 = new JTextField();
		f.getContentPane().add(textField1);
		textField1.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("PW입력:");
		f.getContentPane().add(lblNewLabel_1);

		textField2 = new JPasswordField();

		f.getContentPane().add(textField2);
		textField2.setColumns(10);
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.setFont(new Font("굴림", Font.PLAIN, 15));
		f.getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("회원 가입");
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.setForeground(Color.BLACK);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				회원가입 member = new 회원가입();
				f.setVisible(false);
			}
		});
		btnNewButton_1.setFont(new Font("굴림", Font.PLAIN, 15));
		f.getContentPane().add(btnNewButton_1);
		f.getContentPane().add(l);

		f.setVisible(true);
	}

}
