package 참고;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

import member.MemberDao;
import member.MemberDto;

public class 회원가입 {
	private JTextField textField1;
	private JTextField textField2;
	private JTextField textField3;
	private JTextField textField4;
	private JTextField textField5;

	public 회원가입() {
		JFrame f = new JFrame();

		f.setSize(333, 268);

		JLabel lblNewLabel = new JLabel("ID    입력 : ");
		lblNewLabel.setFont(new Font("굴림", Font.PLAIN, 13));

		textField1 = new JTextField();
		textField1.setFont(new Font("굴림", Font.PLAIN, 15));
		textField1.setColumns(10);

		JButton btnNewButton = new JButton("중복확인");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = textField1.getText();
				MemberDao dao = new MemberDao();
				MemberDto dto = dao.select(id);
				if (id.equals(dto.getId())) {
					JOptionPane.showMessageDialog(null, "중복된 아이디 입니다.");
					textField1.setText("");
				}else if (id == "") {
					JOptionPane.showMessageDialog(null, "ID를 입력해 주세요.");
				}else {
					JOptionPane.showMessageDialog(null, "사용 가능한 아이디 입니다.");
				}

			}
		});
		btnNewButton.setFont(new Font("굴림", Font.PLAIN, 15));

		JLabel lblPw = new JLabel("PW  입력 : ");
		lblPw.setFont(new Font("굴림", Font.PLAIN, 13));

		textField2 = new JPasswordField();
		textField2.setFont(new Font("굴림", Font.PLAIN, 15));
		textField2.setColumns(10);

		textField3 = new JTextField();
		textField3.setFont(new Font("굴림", Font.PLAIN, 15));
		textField3.setColumns(10);

		JLabel label = new JLabel("이름 입력 : ");
		label.setFont(new Font("굴림", Font.PLAIN, 13));

		JLabel label_1 = new JLabel("번호 입력 : ");
		label_1.setFont(new Font("굴림", Font.PLAIN, 13));

		textField4 = new JTextField();
		textField4.setFont(new Font("굴림", Font.PLAIN, 15));
		textField4.setColumns(10);

		textField5 = new JTextField();
		textField5.setFont(new Font("굴림", Font.PLAIN, 15));
		textField5.setColumns(10);

		JLabel label_2 = new JLabel("주소 입력 : ");
		label_2.setFont(new Font("굴림", Font.PLAIN, 13));

		JButton btnNewButton_1 = new JButton("가입");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (textField1.getText().trim().length() == 0) {
					JOptionPane.showMessageDialog(null, "ID를 입력해 주세요.", "ID 입력", JOptionPane.WARNING_MESSAGE);
					textField1.grabFocus();
				} else if (textField2.getText().trim().length() == 0) {
					JOptionPane.showMessageDialog(null, "PW를 입력해 주세요.", "PW 입력", JOptionPane.WARNING_MESSAGE);
					textField2.grabFocus();
				} else if (textField3.getText().trim().length() == 0) {
					JOptionPane.showMessageDialog(null, "이름을 입력해 주세요.", "이름 입력", JOptionPane.WARNING_MESSAGE);
					textField3.grabFocus();
				} else if (textField4.getText().trim().length() == 0) {
					JOptionPane.showMessageDialog(null, "번호를 입력해 주세요.", "번호 입력", JOptionPane.WARNING_MESSAGE);
					textField4.grabFocus();
				} else if (textField5.getText().trim().length() == 0) {
					JOptionPane.showMessageDialog(null, "주소를 입력해 주세요.", "주소 입력", JOptionPane.WARNING_MESSAGE);
					textField5.grabFocus();
				} else {
					MemberDao dao = new MemberDao();
					MemberDto dto = new MemberDto();

					dto.setId(textField1.getText());
					dto.setPw(textField2.getText());
					dto.setName(textField3.getText());
					dto.setTel(textField4.getText());
					dto.setAddr(textField5.getText());

					try {
						dao.insert(dto);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

					로그인 log = new 로그인();
					f.setVisible(false);
				}

			}
		});

		JButton button = new JButton("취소");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				로그인 log = new 로그인();
				f.setVisible(false);
			}
		});
		GroupLayout groupLayout = new GroupLayout(f.getContentPane());
		groupLayout.setHorizontalGroup(groupLayout.createParallelGroup(Alignment.LEADING).addGroup(groupLayout
				.createSequentialGroup().addContainerGap()
				.addGroup(groupLayout.createParallelGroup(Alignment.LEADING).addGroup(groupLayout
						.createSequentialGroup()
						.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING).addGroup(groupLayout
								.createSequentialGroup()
								.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
										.addGroup(groupLayout.createSequentialGroup()
												.addComponent(label, GroupLayout.PREFERRED_SIZE, 72,
														GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(ComponentPlacement.RELATED))
										.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING).addComponent(
												lblNewLabel, GroupLayout.DEFAULT_SIZE, 74, Short.MAX_VALUE)
												.addComponent(lblPw, GroupLayout.DEFAULT_SIZE, 74, Short.MAX_VALUE)))
								.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
										.addGroup(groupLayout.createSequentialGroup()
												.addPreferredGap(ComponentPlacement.RELATED)
												.addComponent(textField1, GroupLayout.PREFERRED_SIZE, 123,
														GroupLayout.PREFERRED_SIZE)
												.addPreferredGap(ComponentPlacement.RELATED).addComponent(btnNewButton))
										.addComponent(textField2, GroupLayout.DEFAULT_SIZE, 219, Short.MAX_VALUE)
										.addComponent(textField3, GroupLayout.DEFAULT_SIZE, 219, Short.MAX_VALUE)))
								.addGroup(groupLayout.createSequentialGroup()
										.addComponent(label_1, GroupLayout.PREFERRED_SIZE, 72,
												GroupLayout.PREFERRED_SIZE)
										.addGap(1).addComponent(textField4, GroupLayout.PREFERRED_SIZE, 219,
												GroupLayout.PREFERRED_SIZE))
								.addGroup(groupLayout.createSequentialGroup()
										.addComponent(label_2, GroupLayout.PREFERRED_SIZE, 72,
												GroupLayout.PREFERRED_SIZE)
										.addGap(1).addComponent(textField5, GroupLayout.PREFERRED_SIZE, 219,
												GroupLayout.PREFERRED_SIZE)))
						.addContainerGap())
						.addGroup(Alignment.TRAILING, groupLayout.createSequentialGroup().addComponent(btnNewButton_1)
								.addGap(18).addComponent(button).addGap(94)))));
		groupLayout.setVerticalGroup(groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup().addContainerGap()
						.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
								.addComponent(btnNewButton).addComponent(textField1, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(ComponentPlacement.RELATED)
						.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
								.addComponent(textField2, GroupLayout.PREFERRED_SIZE, 24, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblPw, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(ComponentPlacement.RELATED)
						.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(label, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
								.addGroup(groupLayout.createSequentialGroup().addGap(1).addComponent(textField3,
										GroupLayout.PREFERRED_SIZE, 24, GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(ComponentPlacement.RELATED)
						.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(label_1, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
								.addGroup(groupLayout.createSequentialGroup().addGap(1).addComponent(textField4,
										GroupLayout.PREFERRED_SIZE, 24, GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(ComponentPlacement.RELATED)
						.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(label_2, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
								.addGroup(groupLayout.createSequentialGroup().addGap(1).addComponent(textField5,
										GroupLayout.PREFERRED_SIZE, 24, GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(ComponentPlacement.UNRELATED)
						.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
								.addComponent(btnNewButton_1, GroupLayout.PREFERRED_SIZE, 34,
										GroupLayout.PREFERRED_SIZE)
								.addComponent(button, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE))
						.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
		f.getContentPane().setLayout(groupLayout);

		f.setVisible(true);
	}
}
