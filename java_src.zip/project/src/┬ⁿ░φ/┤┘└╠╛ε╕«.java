package 참고;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;

public class 다이어리 {
	private JTextField text1;
	private JTextField text2;
	public 다이어리(){
		
		JFrame f = new JFrame("일기 쓰는 프레임...");
		f.setSize(481,473);
		JLabel l = new JLabel("<<<<일기작성날짜>>>>");
		l.setFont(new Font("굴림", Font.PLAIN, 20));
		FlowLayout flow = new FlowLayout();

		f.getContentPane().setLayout(flow);
		f.getContentPane().add(l);
		
		text1 = 	new JTextField();
		text1.setFont(new Font("굴림", Font.PLAIN, 20));
		f.getContentPane().add(text1);
		text1.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("<<<<일기작성제목>>>>");
		lblNewLabel.setFont(new Font("굴림", Font.PLAIN, 20));
		f.getContentPane().add(lblNewLabel);
		
		text2 = new JTextField();
		text2.setFont(new Font("굴림", Font.PLAIN, 20));
		f.getContentPane().add(text2);
		text2.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("<<<<<<<<<<일기작성내용>>>>>>>>>>");
		lblNewLabel_1.setFont(new Font("굴림", Font.PLAIN, 20));
		f.getContentPane().add(lblNewLabel_1);
		
		JTextArea textArea = new JTextArea();
		textArea.setFont(new Font("Monospaced", Font.PLAIN, 15));
		textArea.setColumns(50);
		textArea.setRows(12);
		f.getContentPane().add(textArea);
		
		JButton btnNewButton = new JButton("저장");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					try {
						FileWriter w = new FileWriter(text1.getText()+".txt");
					} catch (IOException e1) {
						e1.printStackTrace();
					}

			}
		});

		btnNewButton.setFont(new Font("굴림", Font.PLAIN, 20));
		f.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("읽기");
		btnNewButton_1.setFont(new Font("굴림", Font.PLAIN, 20));
		f.getContentPane().add(btnNewButton_1);
		
		f.setVisible(true);
	}

}
