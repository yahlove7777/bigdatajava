package 클래스;

public class 내방 {

	public static void main(String[] args) {
		Phone p1 = new Phone();
		p1.company = "apple";
		p1.shape = "네모모양";
		p1.size = 11;
		
		System.out.println(p1.company);
		System.out.println(p1.shape);
		System.out.println(p1.size);
		p1.call();
		p1.text();
		p1.alram();
		
		Phone p2 = new Phone();
		p2.company = "pear";
		p2.shape = "세모모양";
		p2.size = 20;
		
		System.out.println(p2.company);
		System.out.println(p2.shape);
		System.out.println(p2.size);
		
		System.out.println("=================");
		//생성자 이용
		Tv tv1 = new Tv();
		tv1.color = "검정";
		tv1.power = true;
		tv1.size = 50;
		
		tv1.chanul();
		tv1.sound();
		tv1.jack();
		System.out.println(tv1);
		
		//class를 복사해서 만든 tv2를 객체(대상, object)
		//new의 역할: 객체 생성
		//
		Tv tv2 = new Tv();
		tv2.color = "흰색";
		tv2.power = false;
		tv2.size = 100;
		System.out.println(tv2);

		
	}

}
