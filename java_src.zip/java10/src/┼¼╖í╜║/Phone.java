package 클래스;

public class Phone {

//	전화기 => Class
//	- 특징을 찾아서 부품을 만들어야 함.
//	- 특징(attribute, property), 특성, 속성
//	- 정적특성 : 모양, 크기, 회사 => 멤버변수
	
	String company;
	String shape;
	int size;

	
//	- 동적특성 : 전화하다. 문자보내다. 알람을맞추다.=> 멤버메소드
	public String call() {
		return "친구";
		
	}
	public void text() {
		System.out.println("문자하다.");

	}
	public int alram(){
		return 11;
	}
	@Override
	public String toString() {
		return "[company=" + company + ", shape=" + shape + ", size=" + size + "]";
	}
	
	
	
	
	
	
	
	
}
