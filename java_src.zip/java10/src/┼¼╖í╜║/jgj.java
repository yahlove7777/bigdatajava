package 클래스;

import java.awt.FlowLayout;
import java.io.File;
import java.net.URL;
import java.sql.PreparedStatement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JTextPane;

public class jgj {
	static int y;
	static int sum;
	static String temp;
	static String temp2;
	private static JTextField textField;
	private static JTextField textField2;

	public static void main(String[] args) {
		String[] jgj = {"main.PNG","m1.PNG","m2.PNG","m3.PNG"};
		JFrame f = new JFrame();
		f.setTitle("주문하세요..");
		f.setSize(737,576);
		FlowLayout flow = new FlowLayout();
		ImageIcon img = new ImageIcon(jgj[0]);
		JButton ima = new JButton();
		ima.setIcon(img);
		
		f.getContentPane().setLayout(flow);
			JButton b1 = new JButton("짬뽕");
					b1.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							ImageIcon img = new ImageIcon(jgj[2]);
							ima.setIcon(img);
							y++;
							sum += 8000;
							temp = Integer.toString(y);
							temp2 = Integer.toString(sum);
							textField.setText(temp);
							textField2.setText(temp2);
							}
			
						});
					JButton b2 = new JButton("짜장");
					b2.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							ImageIcon img = new ImageIcon(jgj[1]);
							ima.setIcon(img);
							y++;
							sum += 5000;
							temp = Integer.toString(y);
							temp2 = Integer.toString(sum);
							textField.setText(temp);
							textField2.setText(temp2);

						}

					});


					b2.setFont(new Font("굴림", Font.PLAIN, 15));
					f.getContentPane().add(b2);
					b1.setFont(new Font("굴림", Font.PLAIN, 15));
					f.getContentPane().add(b1);
			
			JButton B3 = new JButton("우동");
			B3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					ImageIcon img = new ImageIcon(jgj[3]);
					ima.setIcon(img);
					y++;
					sum += 4000;
					temp = Integer.toString(y);
					temp2 = Integer.toString(sum);
					textField.setText(temp);
					textField2.setText(temp2);

				}
			});
			B3.setFont(new Font("굴림", Font.PLAIN, 15));
			f.getContentPane().add(B3);
			
			JTextPane text1 = new JTextPane();
			text1.setText("개수");
			f.getContentPane().add(text1);
			

			textField = new JTextField();
			f.getContentPane().add(textField);
			textField.setColumns(10);
			
			JTextPane text2 = new JTextPane();
			text2.setText("금액");
			f.getContentPane().add(text2);
			
			textField2 = new JTextField();
			f.getContentPane().add(textField2);
			textField2.setColumns(10);
			
			
			f.getContentPane().add(ima);
			f.setVisible(true);
	}
}

		

