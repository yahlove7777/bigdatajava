package 클래스;

public class Tv {

//	Tv
//	정적 : 전원버튼유무, 사이즈, 색
//	동적 : 채널변경, 소리조절, 잭연결
	
	boolean power;
	int size;
	String color;
	
	public void chanul() {
		System.out.println("채널 변경");
	}

	public void sound() {
		System.out.println("소리조절");
	}

	public void jack() {
		System.out.println("잭 연결");
	}
	
	@Override
	public String toString() {
		return power + " " +size +" "+color;
	}
	
	
	
}
