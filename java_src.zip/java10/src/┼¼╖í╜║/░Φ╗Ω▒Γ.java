package 클래스;

public class 계산기 {
	//자바는 메소드 이름을 동일하게 할 수 있다.
	//하나의 이름으로 동일한 기능을 표현하게 하는 기능.
	//다형성(overloading, 오버로딩)
	
	
	//파라메터 없는 생성자를 기본 생성잔
	public 계산기() {
		// TODO Auto-generated constructor stub
	}
	public int add(int x, int y) {
		return x + y;
	}

	public void add(int x, double y) {
		System.out.println(x + y);
	}
	
	public void add(String x, int y) {
		System.out.println(x + y);
	}
}
