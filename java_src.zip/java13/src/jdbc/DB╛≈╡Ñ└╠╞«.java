package jdbc;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class DB업데이트 {

	public static void main(String[] args){
		String id = JOptionPane.showInputDialog("ID입력");
		String tel = JOptionPane.showInputDialog("TEL입력");

		
		DB처리 db = new DB처리();
		try {
			db.update(id,tel);
		} catch (Exception e) {
			System.out.println("에러발생!!");
			e.printStackTrace();
		}
		

	}

}
