package jdbc;

import javax.swing.JOptionPane;

public class 검색처리 {

	public static void main(String[] args) throws Exception {
		DB처리 db = new DB처리();
		String id = JOptionPane.showInputDialog("아이디 입력");
		MemberDTO dto = new MemberDTO();
		dto.setId(id);
		db.select(dto);
		}

	}

