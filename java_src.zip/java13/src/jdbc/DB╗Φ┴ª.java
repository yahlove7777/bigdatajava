package jdbc;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class DB삭제 {

	public static void main(String[] args){
		String id = JOptionPane.showInputDialog("ID입력");

		
		DB처리 db = new DB처리();
		try {
			db.delete(id);
		} catch (Exception e) {
			System.out.println("에러발생!!");
			e.printStackTrace();
		}

	}

}
