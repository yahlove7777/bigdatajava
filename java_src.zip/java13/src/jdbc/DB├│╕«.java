package jdbc;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.spi.DirStateFactory.Result;





public class DB처리 {
	//정적멤버변수
	Connection con;
	PreparedStatement ps;
	ResultSet rs;
	String url;
	String user;
	String password;
	String sql;
	//멤버메소드
	public void select(MemberDTO dto) throws Exception {
		//1. 드라이버 설정(예외처리)
				Class.forName("com.mysql.jdbc.Driver");
				System.out.println("1. 드라이버 설정 OK");

				//2. DB 연결(DB명, id, pw)
				url = "jdbc:mysql://localhost:3306/bigdata";
				user = "root";
				password = "1234";
				con = DriverManager.getConnection(url, user, password);
				System.out.println("2. DB 연결 OK");
				
				//3. SQL문 선택
				sql = "select * from member where id = ?";
				PreparedStatement ps = con.prepareStatement(sql);
				ps.setString(1, dto.getId());

				
				System.out.println("3. SQL문 결정 OK");
				
				rs = ps.executeQuery();
				if(rs.next()) {
					dto.setId(rs.getString(1));
					dto.setPw(rs.getString(2));
					dto.setName(rs.getString(3));
					dto.setTel(rs.getString(4));
					
					
				}else {
					System.out.println("검색결과가 없습니다.");
				}
				System.out.println("4. SQL문 전송 완료");
		
	}

	public void insert(MemberDTO dto) throws Exception {
		
		//1. 드라이버 설정(예외처리)
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("1. 드라이버 설정 OK");

		//2. DB 연결(DB명, id, pw)
		url = "jdbc:mysql://localhost:3306/bigdata";
		user = "root";
		password = "1234";
		con = DriverManager.getConnection(url, user, password);
		System.out.println("2. DB 연결 OK");
		
		//3. SQL문 선택
		sql = "insert into member values(?,?,?,?)";
		PreparedStatement ps = con.prepareStatement(sql);
		ps = con.prepareStatement(sql);
		ps.setString(1, dto.getId());
		ps.setString(2, dto.getPw());
		ps.setString(3, dto.getName());
		ps.setString(4, dto.getTel());
		
		System.out.println("3. SQL문 결정 OK");
		
		//4. SQL문 전송
		ps.executeUpdate();
		System.out.println("4. SQL문 전송 완료");
	}
	public void update(String id,String tel) throws Exception {
		
		//1. 드라이버 설정(예외처리)
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("1. 드라이버 설정 OK");
		
		//2. DB 연결(DB명, id, pw)
		url = "jdbc:mysql://localhost:3306/bigdata";
		user = "root";
		password = "1234";
		con = DriverManager.getConnection(url, user, password);
		System.out.println("2. DB 연결 OK");
		
		//3. SQL문 선택
		sql = "update member set tel = ? where id = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps = con.prepareStatement(sql);
		ps.setString(1, tel);
		ps.setString(2, id);

		
		System.out.println("3. SQL문 결정 OK");
		
		//4. SQL문 전송
		ps.executeUpdate();
		System.out.println("4. SQL문 전송 완료");
	}
	public void delete(String id) throws Exception {
		
		//1. 드라이버 설정(예외처리)
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("1. 드라이버 설정 OK");
		
		//2. DB 연결(DB명, id, pw)
		url = "jdbc:mysql://localhost:3306/bigdata";
		user = "root";
		password = "1234";
		con = DriverManager.getConnection(url, user, password);
		System.out.println("2. DB 연결 OK");
		
		//3. SQL문 선택
		sql = "delete from member where id = ?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps = con.prepareStatement(sql);
		ps.setString(1, id);
		
		System.out.println("3. SQL문 결정 OK");
		
		//4. SQL문 전송
		ps.executeUpdate();
		System.out.println("4. SQL문 전송 완료");
	}

	
}
