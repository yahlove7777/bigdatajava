package jdbc;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;





public class DB테스트 {

	public static void main(String[] args) throws Exception {
		
		//1. 드라이버 설정(예외처리)
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("1. 드라이버 설정 OK");

		//2. DB 연결(DB명, id, pw)
		String url = "jdbc:mysql://localhost:3306/bigdata";
		String user = "root";
		String password = "1234";
		Connection con = DriverManager.getConnection(url, user, password);
		System.out.println("2. DB 연결 OK");
		
		//3. SQL문 선택
		String sql = "insert into member values('win','win','win','win')";
		PreparedStatement ps = con.prepareStatement(sql);
		System.out.println("3. SQL문 결정 OK");
		//객체화
		//String url1 = "http://www.naver.com";
		//URL url2 = new URL(url);
		
		//4. SQL문 전송
		ps.executeUpdate();
		System.out.println("4. SQL문 전송 완료");
		
		
		

	}

}
