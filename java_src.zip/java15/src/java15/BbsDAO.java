package java15;

import java.sql.*;
import java.util.ArrayList;

import java15.BbsDTO;

public class BbsDAO {

	String url = "jdbc:mysql://localhost:3306/bigdata";
	String user = "root";
	String password = "1234";
	Connection con;
	PreparedStatement ps;
	ResultSet rs;

	public ArrayList selectall() {

		MemDt dto = null;

		ArrayList list = new ArrayList();

		try {

			Class.forName("com.mysql.jdbc.Driver");

			System.out.println("1. 드라이버설정 ok");

			url = "jdbc:mysql://localhost:3306/car";

			user = "root";

			password = "1234";

			con = DriverManager.getConnection(url, user, password);

			System.out.println("2. db연결 ok");

			String sql = "select * from carsale";

			ps = con.prepareStatement(sql);

			System.out.println("3. SQL문 객체화 ok");

			rs = ps.executeQuery();

			System.out.println("4. SQL문 전송 ok");

			while (rs.next()) {

				dto = new CarDTO();

				String id2 = rs.getString(1);

				String name = rs.getString(2);

				String content = rs.getString(3);

				String price = rs.getString(4);

				dto.setId(id2);

				dto.setName(name);

				dto.setContent(content);

				dto.setPrice(price);

				list.add(dto);

			}

		} catch (Exception e) {

			System.out.println("에러발생!!");

			System.out.println(e.getMessage());

		} finally {

			try {

				rs.close();

				ps.close();

				con.close();

			} catch (Exception e) {

				e.printStackTrace();

			}

		}

		return list;

	}

	public BbsDTO select(String inputId) {

		BbsDTO dto = new BbsDTO();

		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("1. 드라이버설정 ok");

			con = DriverManager.getConnection(url, user, password);
			System.out.println("2. db연결 ok");

			String sql = "select * from bbs where id = ?";
			ps = con.prepareStatement(sql);
			ps.setString(1, inputId);
			System.out.println("3. SQL문 객체화 ok");

			rs = ps.executeQuery();
			System.out.println("4. SQL문 전송 ok");

			if (rs.next()) {
				String id = rs.getString(1);
				String title = rs.getString(2);
				String content = rs.getString(3);
				String etc = rs.getString(4);
				dto.setId(id);
				dto.setTitle(title);
				dto.setContent(content);
				dto.setEtc(etc);
			} else
				System.out.println("검색결과가 없습니다.");
		} catch (Exception e) {
			System.out.println("에러발생!!");
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				ps.close();
				con.close();
			} catch (Exception e) {
				e.printStackTrace();
			} // catch
		} // finally
		return dto;
	}// select
}// class
