package 배열2차원;

public class 배열복사 {

	public static void main(String[] args) {
		int[] num = {1,2,3};
		int num2 = 100;
		//변수의 복사(기본)
		
		//배열의 복사(참조, 참조형 변수)
		int num3 = num2;
		System.out.println(num2);
		System.out.println(num3);
		
		num2 = 555;
		System.out.println(num2);
		System.out.println(num3);
		
		System.out.println("==========");
		int[] num4 = num;
		System.out.println(num[0]);
		System.out.println(num4[0]);
		
		num[0] = 555;
		System.out.println(num[0]);
		System.out.println(num4[0]);
		
		System.out.println("---------");
		int[] num5 = num.clone();
		num[0] = 999;
		System.out.println(num[0]);
		System.out.println(num5[0]);
		

	}

}
