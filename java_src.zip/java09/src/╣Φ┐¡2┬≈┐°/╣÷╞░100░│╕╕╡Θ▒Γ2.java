package 배열2차원;

import java.awt.FlowLayout;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JFrame;
import java.awt.Color;
import java.awt.SystemColor;

public class 버튼100개만들기2 {

	public static void main(String[] args) {
		//버튼 들어갈 자리 100개를 만들어 둠.
		
		JFrame f = new JFrame();
		f.setForeground(SystemColor.inactiveCaptionText);
		f.setSize(1000,900);
		f.setTitle("나의 버튼 200개");
		
		
		JButton[] buttons = new JButton[200];
		
		for (int i = 0; i < buttons.length; i++) {
			buttons[i] = new JButton("나는버튼"+i);
		}
		Random random = new Random();
		for (int i = 0; i < buttons.length; i++) {
			int x = random.nextInt(800);
			int y = random.nextInt(800);
			buttons[i].setBounds(x,y,100,50);
			f.getContentPane().add(buttons[i]);
		}

		f.getContentPane().setLayout(null);//배치 부품 안쓰겠다.
		f.setVisible(true);
	}

}
