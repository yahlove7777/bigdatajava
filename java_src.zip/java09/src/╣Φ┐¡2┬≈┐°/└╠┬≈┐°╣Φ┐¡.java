package 배열2차원;

public class 이차원배열 {

	public static void main(String[] args) {
		int[][] seat = new int[3][10];
		int[][] num = {
				{1,2,3},
				{4,5,6}
		};
		//2차원 배열의 값을 출력
		System.out.println(num[0][1]);
		System.out.println(num[1][2]);
		
		//열의 개수는 못구함
		//지정해야함 num[0] = 배열 0행의 열 개수
		System.out.println("배열의 개수(행의 개수): "+num.length);
		System.out.println("배열 0행의 열개수 : "+ num[0].length);
		System.out.println("배열 1행의 열개수 : "+ num[1].length);
		
		for (int i = 0; i < num.length; i++) {
			for (int j = 0; j < num[i].length; j++) {
				System.out.print(num[i][j]);
			}
			System.out.println();
		}
	}

}
