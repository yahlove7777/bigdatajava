package 배열2차원;

import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class 버튼100개만들기 {

	public static void main(String[] args) {
		//버튼 들어갈 자리 100개를 만들어 둠.
		
		JFrame f = new JFrame();
		f.setSize(1100,500);
		f.setTitle("나의 버튼 200개");
		
		
		JButton[] buttons = new JButton[200];
		
		for (int i = 0; i < buttons.length; i++) {
			buttons[i] = new JButton("나는버튼"+i);
		}
		buttons[0].setBounds(50,50,150,100);
		f.add(buttons[0]);
		buttons[1].setBounds(200,50,150,100);
		f.add(buttons[1]);
		buttons[2].setBounds(350,50,150,100);
		f.add(buttons[2]);
		buttons[3].setBounds(500,50,150,100);
		f.add(buttons[3]);
		buttons[4].setBounds(650,50,150,100);
		f.add(buttons[4]);
		f.setLayout(null);//배치 부품 안쓰겠다.
		f.setVisible(true);
	}

}
