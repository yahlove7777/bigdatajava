package 배열2차원;

import java.util.Arrays;

public class 배열정렬 {

	public static void main(String[] args) {
		int[] num = {11,5,33,44,55,66,11,88,99};
		Arrays.sort(num);
		for (int i = 0; i < num.length; i++) {
			System.out.print(num[i]+" ");
		}
		

	}

}
