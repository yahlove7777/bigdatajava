package 배열2차원;

public class Test1 {

	public static void main(String[] args) {
		//1반은 44,55,66
		//2반은 77,88,99,100
		//각 반의 평균
		//전체 출력
		
		int[][] ban = {
				{44,55,66},
				{77,88,99,100}
		};
		
		int aver = 0;
		for (int i = 0; i < ban.length; i++) {
			for (int j = 0; j < ban[i].length; j++) {
				aver += ban[i][j];
			}
			System.out.println(i+1+"반의 평균은 : "+aver/ban[i].length);
				aver = 0;
		}

	}

}
