package 배열2차원;

import java.awt.FlowLayout;
import java.io.File;
import java.net.URL;
import java.sql.PreparedStatement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Test3 {
	static int i = 0;
	public static void main(String[] args) {
		//자바는 필요한부분(class)을 복사해서
		//조립해서 코딩하는 방식
		//부품(객체, 대상)조립식 프로그램
		//객체지향형 프로그램(Object-Oriented Program)
		//color.red : static(정적)
		//new Button : instance
		String[] movies = {"m1.PNG","m2.PNG","m3.PNG","m4.PNG","m5.PNG"};
		JFrame f = new JFrame();
		f.setTitle("나의 영화 정보 시스템");
		f.setSize(300,400);
		FlowLayout flow = new FlowLayout();
		ImageIcon img = new ImageIcon(movies[0]);
		JButton ima = new JButton();
		JButton b1 = new JButton("왼쪽으로");


		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(i <= 0) {
					JOptionPane.showMessageDialog(null, "왼쪽 마지막입니다. 오른쪽버튼을 클릭해주세요.");
					i++;
				}
				else {
					i -= 1;ImageIcon 
					img = new ImageIcon(movies[i]);
					ima.setIcon(img);
				}
				
					
				}

			});
		b1.setFont(new Font("굴림", Font.PLAIN, 15));
		JButton b2 = new JButton("오른쪽으로");
			b2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
		
					if(i >= 4) {
						JOptionPane.showMessageDialog(null, "오른쪽 마지막입니다. 왼쪽버튼을 클릭해주세요.");
						i--;
					}
					else {
						i += 1;
						ImageIcon img = new ImageIcon(movies[i]);
						ima.setIcon(img);
					}
					}

			});
		b2.setFont(new Font("굴림", Font.PLAIN, 15));
		ima.setIcon(img);


			
			//객체화를 해주어야  String을 의미있게 인식한다.
			//URL url = new URL("http://www.naver.com");
			//File file = new File("c://temp/test.txt");
			//SQL sql = new SQL("select * from member");
			
			
			
			
			f.getContentPane().setLayout(flow);
			f.getContentPane().add(b1);
			f.getContentPane().add(b2);
			f.getContentPane().add(ima);

			f.setVisible(true);
	}
}

		

