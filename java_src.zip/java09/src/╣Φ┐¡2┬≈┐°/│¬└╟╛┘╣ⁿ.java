package 배열2차원;

import java.awt.FlowLayout;
import java.io.File;
import java.net.URL;
import java.sql.PreparedStatement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class 나의앨범 {

	public static void main(String[] args) {
		//자바는 필요한부분(class)을 복사해서
		//조립해서 코딩하는 방식
		//부품(객체, 대상)조립식 프로그램
		//객체지향형 프로그램(Object-Oriented Program)
		//color.red : static(정적)
		//new Button : instance
		String[] movies = {"m1.PNG","m2.PNG","m3.PNG","m4.PNG","m5.PNG"};
		JFrame f = new JFrame();
		f.setTitle("나의 영화 정보 시스템");
		f.setSize(300,565);
		FlowLayout flow = new FlowLayout();

		JButton ima = new JButton();
		ImageIcon img = new ImageIcon(movies[0]);
		ima.setIcon(img);
	
		JButton b1 = new JButton("<<<생일>>>>");
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ImageIcon img = new ImageIcon(movies[0]);
				ima.setIcon(img);
			}
		});
		b1.setFont(new Font("굴림", Font.PLAIN, 20));
		JButton b2 = new JButton("<<<헬보이>>>");
		b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ImageIcon img = new ImageIcon(movies[1]);
				ima.setIcon(img);
			}
		});
		b2.setFont(new Font("굴림", Font.PLAIN, 20));
		JButton b3 = new JButton("<<돈(Money)>>");
		b3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ImageIcon img = new ImageIcon(movies[2]);
				ima.setIcon(img);
			}
		});
		b3.setFont(new Font("굴림", Font.PLAIN, 20));
		JButton b4 = new JButton("<<파이브 피트>>");
		b4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ImageIcon img = new ImageIcon(movies[3]);
				ima.setIcon(img);
			}
		});
		b4.setFont(new Font("굴림", Font.PLAIN, 20));
		JButton b5 = new JButton("<<<<어스>>>>");
		b5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ImageIcon img = new ImageIcon(movies[4]);
				ima.setIcon(img);
			}
		});
		b5.setFont(new Font("굴림", Font.PLAIN, 20));


	
		//객체화를 해주어야  String을 의미있게 인식한다.
		//URL url = new URL("http://www.naver.com");
		//File file = new File("c://temp/test.txt");
		//SQL sql = new SQL("select * from member");
		
		
		
		
		
		
		f.getContentPane().setLayout(flow);
		f.getContentPane().add(ima);
		f.getContentPane().add(b1);
		f.getContentPane().add(b2);
		f.getContentPane().add(b3);
		f.getContentPane().add(b4);
		f.getContentPane().add(b5);
		f.setVisible(true);
		
		
		

	}

}
