package 정적변수;

public class MoneyTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
