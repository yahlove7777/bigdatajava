package 정적변수;

public class Money {
	
	String name;
	int age;
	
	static int money;
	
	public Money() {
		
	}
}
