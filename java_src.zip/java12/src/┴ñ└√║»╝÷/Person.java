package 정적변수;

public class Person {
	int height;
	int weight;
	String secret;
	String address;
	
	
	public Person() {
		
	}
	public Person(int height, int weight, String secret) {
		
		this.height = height;
		this.weight = weight;
		this.secret = secret;
	}
	public int getWeight() {
		return weight;
	}
	public String getSecret() {
		return secret;
	}
}
