package 정적변수;

public class Worker {
	
	String name;
	String gender;
	int age;
	static int count;
	static int sum;
	
	public Worker(String name, String gender, int age) {
		
		this.name = name;
		this.gender = gender;
		this.age = age;
		sum += age;
		count++;
	}

	@Override
	public String toString() {
		return "[name=" + name + ", gender=" + gender + ", age=" + age + "]";
	}
	
	

}
