package 정적변수;

public class StringTest {

	public static void main(String[] args) {
		String s1 = "abc";
		String s2 = "def";
		String s3 = "";
		
		System.out.println(s1.charAt(0));
		System.out.println(s1.compareTo(s1));
		System.out.println(s1.concat(s2));
		System.out.println(s1.equalsIgnoreCase(s2));
		System.out.println(s3.isEmpty());
		System.out.println(s1.length());
		

	}

}
