package 정적변수;

public class Clock {

	int price, nowTime;
	String name, company;

	public Clock(int price, String name, int nowTime, String company) {
		this.price = price;
		this.name = name;
		this.nowTime = nowTime;
		this.company = company;
	}
	public Clock(int price,int nowTime, String company) {
		this.price = price;
		this.name = name;
		this.nowTime = nowTime;
		this.company = company;
	}
	public Clock(int price, String company) {
		this.price = price;
		this.name = name;
		this.nowTime = nowTime;
		this.company = company;
	}
	public String geycompany() {
		return company;
	}
	public int getPrice() {
		return price;
	}

}
