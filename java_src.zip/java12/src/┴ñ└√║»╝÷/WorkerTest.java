package 정적변수;

public class WorkerTest {

	public static void main(String[] args) {
		
		Worker w1 = new Worker("임아무개","남",24);
		Worker w2 = new Worker("김아무개","여",23);
		Worker w3 = new Worker("최아무개","남",25);
		
		
		System.out.println("전체 직원의 수는 : "+Worker.count);
		System.out.println("직원들의 평균 나이 : "+Worker.sum/Worker.count);
		System.out.println("전체 직원 리스트");
		System.out.println(w1);
		System.out.println(w2);
		System.out.println(w3);

	}

}
