package 정적변수;

public class Day {
	
	
	String work;
	int time;
	String wkdth;
	static int count;
	static int sum;
	
	
	public Day(String work, int time, String wkdth) {
		
		this.work = work;
		this.time = time;
		this.wkdth = wkdth;
		sum += time;
		count++;
		
	}
	public static int getTotal() {
		return sum;
	}


	@Override
	public String toString() {
		return "[work=" + work + ", time=" + time + ", wkdth=" + wkdth + "]";
	}
	

}
