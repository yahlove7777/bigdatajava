package 정적변수;


public class DayTest {

	public static void main(String[] args) {
		
		Day d1 = new Day("자바공부",10,"강남");
		Day d2 = new Day("여행",15,"강원도");
		Day d3 = new Day("운동",11,"피트니스");
		
		
		System.out.println("전체 하는 일의 시간 : "+Day.sum);
		System.out.println("평균 하는 일의 시간 : "+Day.sum/Day.count);
		System.out.println("매일 무엇을 얼마나 어디서 했는지 프린트 ");
		System.out.println(d1);
		System.out.println(d2);
		System.out.println(d3);
		System.out.println("며칠 간 했는지 : "+Day.count);
		System.out.println(Day.getTotal());

	}

}
