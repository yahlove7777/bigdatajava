package test;

import java.util.Scanner;

public class Test2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String[] name = {"김아무개","박아무개","송아무개","정아무개","최아무개"};
		int[] hak = {1,2,3,1,1};
		char[] num = {'A','B','C','A','B'};
		int[] hakrank = new int[4];
		int[] numrank = new int[5];
		for (int i = 0; i < num.length; i++) {
			System.out.println("이름: "+name[i]+", 학년: "+hak[i]+", 학점: "+num[i]);
		}
		System.out.println();
		for (int i = 0; i < hak.length; i++) {
			switch(hak[i]) {
			case 1: hakrank[0]++; break;
			case 2: hakrank[1]++; break;
			case 3: hakrank[2]++; break;
			case 4: hakrank[3]++; break;
			}

		}
		for (int i = 0; i < hakrank.length; i++) {
			System.out.println(i+1+"학년: "+hakrank[i]+"명");
		}
		System.out.println();
		for (int i = 0; i < num.length; i++) {
			switch(num[i]) {
			case 'A': numrank[0]++; break;
			case 'B': numrank[1]++; break;
			case 'C': numrank[2]++; break;
			case 'D': numrank[3]++; break;
			case 'F': numrank[4]++; break;
			}
		}
		char[] num2 = {'A','B','C','D','F'};
		for (int i = 0; i < numrank.length; i++) {
			System.out.println(num2[i]+"학점: "+numrank[i]+"명");
		}
		System.out.println();
		
		System.out.print("정보를 찾을 이름을 입력하세요 : ");
		String namesc = sc.next();
		int x = 0;
		for (int i = 0; i < name.length; i++) {
			if(namesc.equals(name[i])) {
				x = i;
			}
		}
		System.out.println(name[x]+"의 위치는 : "+x);
		System.out.println("학년은 : "+hak[x]);
		System.out.println("학점은 : "+num[x]);
		
	}

	
}
