package test;

import java.util.Scanner;

public class Test3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String[] name = new String[5];
		int[] age = new int[5];
		double aver = 0;
		System.out.println("이름과 나이를 입력하세요.");
		for (int i = 0; i < age.length; i++) {
			System.out.print("입력 >> ");
			name[i] = sc.next();
			age[i] = sc.nextInt();
		}
		
		for (int i = 0; i < age.length; i++) {
			System.out.println("이름은 : "+name[i]+", 나이는: "+age[i]);
		}
		for (int i = 0; i < age.length; i++) {
			aver += age[i];
		}
		aver = aver / age.length;
		System.out.println("파티 참석자 나이의 평균은 "+aver);
		

	}

	
}
